package dtcc.itn262;

public class Main {
	public static void main(String[] args) {
		AirportController airportController = new AirportController();
		airportController.startSimulation();
	}
}